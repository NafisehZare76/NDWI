import tiffile as tiff
from  NDWI import NDWI

#read image:
image=tiff.imread("2_chitgar_img.tif")
ndwi=NDWI(image)
export_img=tiff.imwrite('ndwi_chitgar.tif',ndwi)
#show=tiff.imshow(ndwi)
print('sucsefull:)')